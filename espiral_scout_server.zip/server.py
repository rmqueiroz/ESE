
import os
import json
from flask import Flask, request, jsonify, abort
from dotenv import load_dotenv
from engine_core import handle_scout_message, HEALTH_SIGNATURE

load_dotenv()

app = Flask(__name__)

VERIFY_TOKEN = os.getenv("WHATSAPP_VERIFY_TOKEN", "changeme")
ALLOWED_GROUP_IDS = set(x.strip() for x in os.getenv("ALLOWED_GROUP_IDS", "").split(",") if x.strip())
REQUIRE_MENTION = os.getenv("REQUIRE_MENTION", "true").lower() == "true"

@app.route("/", methods=["GET"])
def root():
    return jsonify({"ok": True, "service": "Espiral Scout Engine", "sig": HEALTH_SIGNATURE})

@app.route("/webhook", methods=["GET"])
def verify():
    mode = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge")
    if mode == "subscribe" and token == VERIFY_TOKEN:
        return challenge, 200
    return abort(403)

@app.route("/webhook", methods=["POST"])
def receive():
    payload = request.get_json(silent=True) or {}
    if "entry" not in payload:
        return jsonify({"status": "ignored"}), 200

    events = []
    try:
        for entry in payload.get("entry", []):
            for change in entry.get("changes", []):
                value = change.get("value", {})
                for msg in value.get("messages", []):
                    events.append({"msg": msg, "meta": value})
    except Exception:
        pass

    responses = []
    for ev in events:
        msg = ev["msg"]
        meta = ev["meta"]
        text = (msg.get("text") or {}).get("body", "")

        group_id = (msg.get("from") or "").strip()

        if ALLOWED_GROUP_IDS and group_id not in ALLOWED_GROUP_IDS:
            continue

        if REQUIRE_MENTION and "@scout" not in text.lower():
            continue

        try:
            after = text.split("@scout", 1)[1].strip()
        except Exception:
            after = ""

        if not after:
            continue

        card_text = handle_scout_message(after)

        responses.append({
            "to": group_id,
            "message": card_text
        })

    return jsonify({"processed": len(responses), "responses_preview": responses}), 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8000")))
