# Espiral Scout Engine — Pacote de Servidor (Render.com)

Webhook Flask pronto para Render.com + WhatsApp Cloud API (modo seguro).

## Deploy rápido
1) Suba estes arquivos em um repositório (GitHub/GitLab).
2) No Render.com: New Web Service → conecte o repo.
3) Start command: `gunicorn server:app`
4) Vars de ambiente: `WHATSAPP_VERIFY_TOKEN`, `ALLOWED_GROUP_IDS` (opcional), `REQUIRE_MENTION=true`.
5) Configure o webhook no Meta (GET /webhook verificação).

## Uso
Mencione: `@scout Nome` no grupo autorizado. O servidor retorna uma **prévia** JSON do cartão (não envia mensagem).

## Próximos passos
- Adicionar worker de envio (Graph API) para postar no grupo.
- Integrar fontes reais e cache persistente (SQLite).

Coautoria técnica: Raphael & Clara — Espiral Scout Engine.
