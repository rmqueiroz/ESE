
import re

HEALTH_SIGNATURE = "espiral-scout-engine-core-0.9.9.2"

def normalize_whitespace(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").strip()

def parse_query(q: str):
    q = (q or "").strip()
    parts = [normalize_whitespace(p) for p in q.split(",") if p.strip()]
    name = parts[0] if parts else ""
    filters = [p for p in parts[1:]]
    return name, filters

def render_card(name, data):
    lines = []
    lines.append(f"⚽ **{data.get('display_name', name)} ({data.get('position', '—')})**")
    phys = " • ".join(x for x in [
        f"{data.get('age', '—')} anos" if data.get('age') else None,
        f"{data.get('height', '—')} m" if data.get('height') else None,
        f"🦶 {data.get('foot', '—')}" if data.get('foot') else None
    ] if x)
    if phys:
        lines.append(f"🎯 {phys}")
    lines.append(f"🏟️ **Clube atual:** {data.get('club_current', '—')}")
    if data.get("contract_until"):
        lines.append(f"📅 **Contrato até:** {data['contract_until']}")
    if data.get("youth_club"):
        lines.append(f"🎓 **Formação:** {data['youth_club']}")
    if data.get("club_previous"):
        lines.append(f"🔄 **Clube anterior:** {data['club_previous']}")
    if data.get("market_value_eur"):
        lines.append(f"💰 **Valor de mercado:** € {data['market_value_eur']}")
    if data.get("tm_link"):
        lines.append(f"🔗 {data['tm_link']}")
    return "\n".join(lines)

def handle_scout_message(raw: str) -> str:
    name, filters = parse_query(raw)
    key = normalize_whitespace(name.lower())

    catalog = {
        "john kennedy": {
            "display_name": "John Kennedy (Atacante)",
            "position": "Atacante",
            "age": 23,
            "height": "1,73",
            "foot": "destro",
            "club_current": "Fluminense",
            "contract_until": "31/12/2027",
            "youth_club": "Fluminense (Xerém)",
            "club_previous": "Pachuca (MEX) — empréstimo encerrado em 07/2025",
            "market_value_eur": "6.000.000",
            "tm_link": "https://www.transfermarkt.pt/john-kennedy/profil/spieler/856085"
        },
        "marlon": {
            "display_name": "Marlon Santos da Silva Barbosa (Zagueiro)",
            "position": "Zagueiro",
            "age": 30,
            "height": "1,82",
            "foot": "destro",
            "club_current": "Shakhtar Donetsk (UCR)",
            "contract_until": "30/06/2026",
            "youth_club": "Fluminense",
            "club_previous": "Fluminense (BRA)",
            "market_value_eur": "3.500.000",
            "tm_link": "https://www.transfermarkt.us/marlon/profil/spieler/273236"
        }
    }

    data = catalog.get(key, {
        "display_name": name,
        "position": "—",
        "age": None,
        "height": None,
        "foot": None,
        "club_current": "—",
        "contract_until": None,
        "youth_club": None,
        "club_previous": None,
        "market_value_eur": None,
        "tm_link": None
    })

    return render_card(name, data)
